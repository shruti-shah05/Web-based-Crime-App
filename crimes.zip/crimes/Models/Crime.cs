//
// Crime
//

namespace crimes.Models
{

  public class Crime
	{
	
		// data members with auto-generated getters and setters:
	  public string IUCR { get; set; }
		public string PrimaryDesc { get; set; }
		public string SecondaryDesc { get; set; }
		public int NumCrimes{ get; set; }
		public double per_crime{ get; set; }
		public double per_arrested { get; set; }
		public int Area { get; set; }
		public string AreaName { get; set; }
	    public int Year { get; set; }
		public int CID { get; set; }
	    public string CrimeDate { get; set; }
	    public int District { get; set; }
	
		// default constructor:
		public Crime()
		{ }
		
		// constructor:
		public Crime(string IUCR_CODE, string primary, string secondary, int numCrimes, double perCrime, double perArrested, int area, string areaName, int year, int cid, string crimeDate, int district)
		{
			IUCR = IUCR_CODE;
			PrimaryDesc = primary;
			SecondaryDesc = secondary;
			NumCrimes = numCrimes;
			per_crime = perCrime;
			per_arrested = perArrested;
			Area = area;
			AreaName = areaName;
			Year = year;
			CID = cid;
			CrimeDate = crimeDate;
			District = district;
		}
		
	}//class

}//namespace